import sqlite3, json, secrets, bcrypt
from pathlib import Path
from datetime import datetime
import jdatetime
from .config import DATA_DIR, ARCHIVE_DIR, SUPER_LICENSE, RESET_SUPER_LICENSE

MAIN_DB = DATA_DIR / "main.sqlite3"

def now_iso():
    return datetime.now().astimezone().isoformat(timespec="seconds")

def shamsi_now():
    return jdatetime.datetime.now().strftime("%Y-%m-%d %H:%M")

def month_key():
    return jdatetime.datetime.now().strftime("%Y-%m")

def month_label(key=None):
    if key:
        y, m = map(int, key.split("-"))
        return f"{jdatetime.date(y, m, 1).strftime('%B')}_{y}"
    return jdatetime.datetime.now().strftime("%B_%Y")

def connect(path=MAIN_DB):
    con = sqlite3.connect(str(path), timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA journal_mode=WAL")
    return con

def init_db():
    with connect() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS offices(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, created_at TEXT NOT NULL,
          deleted_at TEXT, active INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id INTEGER UNIQUE NOT NULL,
          full_name TEXT NOT NULL, role TEXT NOT NULL, office_id INTEGER,
          active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL,
          FOREIGN KEY(office_id) REFERENCES offices(id)
        );
        CREATE TABLE IF NOT EXISTS licenses(
          id INTEGER PRIMARY KEY AUTOINCREMENT, token_hash TEXT NOT NULL UNIQUE,
          role TEXT NOT NULL, office_id INTEGER, created_by INTEGER, created_at TEXT NOT NULL,
          used_at TEXT, revoked INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS super_auth(id INTEGER PRIMARY KEY CHECK(id=1), password_hash BLOB NOT NULL, updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS property_fields(
          id INTEGER PRIMARY KEY AUTOINCREMENT, field_key TEXT NOT NULL, label TEXT NOT NULL,
          data_type TEXT NOT NULL DEFAULT 'text', required INTEGER NOT NULL DEFAULT 0,
          property_type TEXT NOT NULL DEFAULT '*', deal_type TEXT NOT NULL DEFAULT '*',
          options TEXT, sort_order INTEGER NOT NULL DEFAULT 0, enabled INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS match_weights(
          property_type TEXT NOT NULL, field_key TEXT NOT NULL, weight REAL NOT NULL,
          PRIMARY KEY(property_type, field_key)
        );
        CREATE TABLE IF NOT EXISTS properties(
          id INTEGER PRIMARY KEY AUTOINCREMENT, office_id INTEGER NOT NULL, created_by INTEGER NOT NULL,
          assigned_to INTEGER, property_type TEXT NOT NULL, deal_type TEXT NOT NULL,
          address TEXT NOT NULL, area REAL, price REAL, deposit REAL, rent REAL,
          owner_name TEXT NOT NULL, owner_phone TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'فعال',
          fields_json TEXT NOT NULL DEFAULT '{}', description TEXT DEFAULT '', photo_file_id TEXT,
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
          FOREIGN KEY(office_id) REFERENCES offices(id)
        );
        CREATE INDEX IF NOT EXISTS idx_properties_office ON properties(office_id);
        CREATE TABLE IF NOT EXISTS clients(
          id INTEGER PRIMARY KEY AUTOINCREMENT, office_id INTEGER NOT NULL, created_by INTEGER NOT NULL,
          assigned_to INTEGER, name TEXT NOT NULL, phone TEXT DEFAULT '', property_type TEXT NOT NULL,
          deal_type TEXT NOT NULL, budget REAL NOT NULL, area_min REAL, area_max REAL,
          location TEXT NOT NULL, required_json TEXT NOT NULL DEFAULT '{}', need_date TEXT DEFAULT '',
          threshold INTEGER NOT NULL DEFAULT 70, source TEXT DEFAULT '', stage TEXT DEFAULT 'جدید',
          last_followup TEXT, notes TEXT DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
          FOREIGN KEY(office_id) REFERENCES offices(id)
        );
        CREATE INDEX IF NOT EXISTS idx_clients_office ON clients(office_id);
        CREATE TABLE IF NOT EXISTS visits(
          id INTEGER PRIMARY KEY AUTOINCREMENT, office_id INTEGER NOT NULL, property_id INTEGER NOT NULL,
          client_id INTEGER NOT NULL, created_by INTEGER NOT NULL, visit_at TEXT NOT NULL,
          result TEXT DEFAULT '', notes TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS notes(
          id INTEGER PRIMARY KEY AUTOINCREMENT, office_id INTEGER NOT NULL, entity_type TEXT NOT NULL,
          entity_id INTEGER NOT NULL, user_id INTEGER NOT NULL, body TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS history(
          id INTEGER PRIMARY KEY AUTOINCREMENT, office_id INTEGER NOT NULL, entity_type TEXT NOT NULL,
          entity_id INTEGER NOT NULL, user_id INTEGER NOT NULL, action TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS chat_messages(
          id INTEGER PRIMARY KEY AUTOINCREMENT, office_id INTEGER NOT NULL, telegram_id INTEGER NOT NULL,
          sender TEXT NOT NULL, body TEXT NOT NULL, related_type TEXT DEFAULT '', related_id INTEGER,
          month_key TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS deleted_offices(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, deleted_at TEXT NOT NULL, archive_path TEXT NOT NULL
        );
        """)
        if not c.execute("SELECT 1 FROM property_fields LIMIT 1").fetchone():
            seed_fields(c)
        if not c.execute("SELECT 1 FROM match_weights LIMIT 1").fetchone():
            seed_weights(c)
        if RESET_SUPER_LICENSE == "1" and SUPER_LICENSE:
            hashed = bcrypt.hashpw(SUPER_LICENSE.encode(), bcrypt.gensalt())
            c.execute("INSERT INTO super_auth(id,password_hash,updated_at) VALUES(1,?,?) ON CONFLICT(id) DO UPDATE SET password_hash=excluded.password_hash,updated_at=excluded.updated_at", (hashed, now_iso()))
        elif not c.execute("SELECT 1 FROM super_auth WHERE id=1").fetchone() and SUPER_LICENSE:
            hashed = bcrypt.hashpw(SUPER_LICENSE.encode(), bcrypt.gensalt())
            c.execute("INSERT INTO super_auth(id,password_hash,updated_at) VALUES(1,?,?)", (hashed, now_iso()))
        c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('schema_version','1')")

def seed_fields(c):
    rows = [
      ('property_type','نوع ملک','choice',1,'*','*','آپارتمان|ویلا/خانه|تجاری|اداری|زمین/باغ|صنعتی|کشاورزی',1),
      ('deal_type','نوع معامله','choice',1,'*','*','خرید و فروش|رهن و اجاره|پیش‌فروش|مشارکت در ساخت',2),
      ('address','محله/آدرس','text',1,'*','*','',3),
      ('area','متراژ (متر)','number',1,'*','*','',4),
      ('price','قیمت کل (تومان)','number',0,'*','خرید و فروش','',5),
      ('deposit','رهن (تومان)','number',0,'*','رهن و اجاره','',6),
      ('rent','اجاره ماهانه (تومان)','number',0,'*','رهن و اجاره','',7),
      ('owner_name','نام مالک','text',1,'*','*','',8),
      ('owner_phone','شماره مالک','phone',1,'*','*','',9),
      ('status','وضعیت فایل','choice',1,'*','*','فعال|معامله‌شده|منقضی',10),
      ('description','توضیحات','text',0,'*','*','',11),
    ]
    for r in rows:
        c.execute("INSERT INTO property_fields(field_key,label,data_type,required,property_type,deal_type,options,sort_order) VALUES(?,?,?,?,?,?,?,?)", r)
    groups = {
      'آپارتمان': [('floor','طبقه',1),('rooms','اتاق',1),('vacancy','وضعیت تخلیه',1),('building_age','سن بنا',1),('floors_total','تعداد طبقات',0),('direction','جهت',0),('document','سند',0),('parking','پارکینگ',0),('elevator','آسانسور',0),('storage','انباری',0),('cabinet','کابینت',0),('heating_cooling','گرمایش/سرمایش',0)],
      'ویلا/خانه': [('land_area','متراژ زمین',1),('building_area','متراژ بنا',1),('rooms','اتاق',1),('document','سند',1),('floors_total','طبقات',0),('building_age','سن بنا',0),('yard','حیاط',0),('pool','استخر',0),('parking','پارکینگ',0)],
      'تجاری': [('frontage','دهنه',1),('permitted_use','کاربری مجاز',1),('permit','سند/پروانه',1),('depth','عمق',0),('floor','طبقه',0),('storage','انباری',0),('position','موقعیت',0),('goodwill','سرقفلی',0)],
      'اداری': [('floor','طبقه',1),('office_document','سند اداری',1),('rooms','اتاق',0),('elevator','آسانسور',0),('parking','پارکینگ',0),('facilities','تأسیسات',0),('lobby','لابی',0)],
      'زمین/باغ': [('land_use','کاربری',1),('document','سند (شش‌دانگ/قولنامه‌ای)',1),('frontage','طول بر',1),('slope','شیب',0),('utilities','آب/برق/گاز',0),('density','تراکم و ارتفاع مجاز',0),('building_restriction','ممنوعیت ساخت',0)],
      'صنعتی': [('hall_area','متراژ سالن',1),('electricity','برق (کیلووات/سه‌فاز)',1),('operating_license','پروانه بهره‌برداری',1),('ceiling_height','ارتفاع سقف',0),('water','آب',0),('gas','گاز',0),('truck_access','دسترسی تریلی',0),('industrial_zone','داخل/خارج شهرک',0)],
      'کشاورزی': [('water_source','منبع آب',1),('document','سند',1),('crop','نوع محصول/درختان',0),('fence','حصار',0),('electricity','برق',0),('road_access','راه دسترسی',0)]
    }
    n=20
    for typ, fields in groups.items():
        for key,label,req in fields:
            c.execute("INSERT INTO property_fields(field_key,label,data_type,required,property_type,deal_type,options,sort_order) VALUES(?,?,?,?,?,?,?,?,?)".replace(",?,?,?,?,?,?,?,?,?)",",?,?,?,?,?,?,?,?)"),
                      (key,label,'text',req,typ,'*',None,n))
            n += 1
    deals = {
      'خرید و فروش': [('total_price','قیمت کل',1),('vacancy','وضعیت تخلیه',1),('payment_terms','شرایط پرداخت',0),('exchange','قابل معاوضه',0)],
      'رهن و اجاره': [('deposit','رهن',1),('rent','اجاره',1),('vacate_date','تاریخ تخلیه',1),('contract_length','مدت قرارداد',0),('convertible','قابل تبدیل',0)],
      'پیش‌فروش': [('builder','سازنده',1),('building_permit','پروانه ساخت',1),('delivery_date','تاریخ تحویل',1),('progress','درصد پیشرفت',0),('installments','شرایط اقساط',0)],
      'مشارکت در ساخت': [('land_area','متراژ زمین',1),('document','سند',1),('share_ratio','نسبت مشارکت',1),('plan','پروانه/طرح',0),('density','تراکم',0)]
    }
    for typ, fields in deals.items():
        for key,label,req in fields:
            c.execute("INSERT INTO property_fields(field_key,label,data_type,required,property_type,deal_type,options,sort_order) VALUES(?,?,?,?,?,?,?,?)",
                      (key,label,'text',req,'*',typ,None,n))
            n += 1
    # Customer fields are represented in this configuration table too.
    for key,label,req in [('client_budget','بودجه',1),('client_location','محدوده',1),('client_area_min','حداقل متراژ',0),('client_features','امکانات الزامی',0),('client_need_date','تاریخ نیاز',0),('client_threshold','آستانه تطبیق',0),('client_source','منبع جذب',0),('business_type','نوع کسب‌وکار',0)]:
        c.execute("INSERT INTO property_fields(field_key,label,data_type,required,property_type,deal_type,options,sort_order) VALUES(?,?,?,?,?,?,?,?)",
                  (key,label,'text',req,'*','*',None,n))
        n += 1

def seed_weights(c):
    defaults = {
      'آپارتمان': {'budget':30,'location':25,'area':15,'rooms':10,'features':10,'floor_need_date':10},
      'زمین/باغ': {'budget':20,'location':20,'area':10,'land_use':25,'document':25},
      'تجاری': {'budget':20,'location':25,'area':10,'frontage':25,'permitted_use':20},
      'ویلا/خانه': {'budget':30,'location':20,'area':15,'rooms':10,'features':15,'document':10},
      'اداری': {'budget':30,'location':25,'area':15,'floor':10,'features':20},
      'صنعتی': {'budget':25,'location':20,'area':15,'electricity':20,'operating_license':20},
      'کشاورزی': {'budget':20,'location':15,'area':15,'water_source':25,'document':25}
    }
    for typ, weights in defaults.items():
        for k,w in weights.items():
            c.execute("INSERT OR IGNORE INTO match_weights(property_type,field_key,weight) VALUES(?,?,?)",(typ,k,w))

def office_db_path(office_id):
    return DATA_DIR / f"office_{int(office_id)}_chat.sqlite3"

def chat_db_init(office_id):
    with connect(office_db_path(office_id)) as c:
        c.execute("""CREATE TABLE IF NOT EXISTS chat_messages(
        id INTEGER PRIMARY KEY AUTOINCREMENT, office_id INTEGER NOT NULL, telegram_id INTEGER NOT NULL,
        sender TEXT NOT NULL, body TEXT NOT NULL, related_type TEXT DEFAULT '', related_id INTEGER,
        month_key TEXT NOT NULL, created_at TEXT NOT NULL)""")

def password_check(candidate):
    with connect() as c:
        row=c.execute("SELECT password_hash FROM super_auth WHERE id=1").fetchone()
    return bool(row and bcrypt.checkpw(candidate.encode(), row["password_hash"]))

def change_super_password(candidate):
    hashed=bcrypt.hashpw(candidate.encode(), bcrypt.gensalt())
    with connect() as c:
        c.execute("UPDATE super_auth SET password_hash=?,updated_at=? WHERE id=1",(hashed,now_iso()))

def issue_license(role, office_id, created_by):
    token=secrets.token_urlsafe(36)
    digest=bcrypt.hashpw(token.encode(), bcrypt.gensalt()).decode()
    # Store an HMAC-like hash for exact lookup; bcrypt salts prevent lookup. Use SHA-256 digest for indexed lookup.
    import hashlib
    digest=hashlib.sha256(token.encode()).hexdigest()
    with connect() as c:
        cur=c.execute("INSERT INTO licenses(token_hash,role,office_id,created_by,created_at) VALUES(?,?,?,?,?)",
                      (digest,role,office_id,created_by,now_iso()))
        lid=cur.lastrowid
    return token, lid

def consume_license(token, telegram_id, full_name):
    import hashlib
    digest=hashlib.sha256(token.strip().encode()).hexdigest()
    with connect() as c:
        lic=c.execute("SELECT * FROM licenses WHERE token_hash=? AND used_at IS NULL AND revoked=0",(digest,)).fetchone()
        if not lic:
            return None
        if lic["role"] not in ("office_admin","consultant") or not lic["office_id"]:
            return None
        office=c.execute("SELECT active FROM offices WHERE id=?",(lic["office_id"],)).fetchone()
        if not office or not office["active"]:
            return None
        c.execute("UPDATE licenses SET used_at=? WHERE id=? AND used_at IS NULL",(now_iso(),lic["id"]))
        cur=c.execute("INSERT INTO users(telegram_id,full_name,role,office_id,created_at) VALUES(?,?,?,?,?)",
                      (telegram_id,full_name,lic["role"],lic["office_id"],now_iso()))
        c.execute("INSERT INTO history(office_id,entity_type,entity_id,user_id,action,created_at) VALUES(?,?,?,?,?,?)",
                  (lic["office_id"],"user",cur.lastrowid,cur.lastrowid,"ورود با لایسنس",now_iso()))
        return dict(user_id=cur.lastrowid,role=lic["role"],office_id=lic["office_id"])

def get_user(telegram_id):
    with connect() as c:
        row=c.execute("SELECT * FROM users WHERE telegram_id=? AND active=1",(telegram_id,)).fetchone()
    return dict(row) if row else None

def user_by_id(user_id, office_id=None):
    with connect() as c:
        if office_id is None:
            row=c.execute("SELECT * FROM users WHERE id=? AND active=1",(user_id,)).fetchone()
        else:
            row=c.execute("SELECT * FROM users WHERE id=? AND office_id=? AND active=1 AND role!='super_admin'",(user_id,office_id)).fetchone()
    return dict(row) if row else None

def create_office(name, creator_id):
    with connect() as c:
        cur=c.execute("INSERT INTO offices(name,created_at) VALUES(?,?)",(name.strip(),now_iso()))
        oid=cur.lastrowid
    chat_db_init(oid)
    token,_=issue_license("office_admin",oid,creator_id)
    return oid,token

def list_offices(include_deleted=False):
    with connect() as c:
        rows=c.execute("SELECT * FROM offices WHERE active=? ORDER BY id DESC",(0 if include_deleted else 1,)).fetchall()
    return [dict(r) for r in rows]

def list_users(office_id):
    with connect() as c:
        rows=c.execute("SELECT id,telegram_id,full_name,role,created_at FROM users WHERE office_id=? AND active=1 AND role!='super_admin' ORDER BY id",(office_id,)).fetchall()
    return [dict(r) for r in rows]

def remove_user(user_id, office_id=None):
    with connect() as c:
        if office_id is None:
            c.execute("UPDATE users SET active=0 WHERE id=? AND role!='super_admin'",(user_id,))
        else:
            c.execute("UPDATE users SET active=0 WHERE id=? AND office_id=? AND role!='super_admin'",(user_id,office_id))

def create_consultant_license(office_id, creator_id):
    return issue_license("consultant",office_id,creator_id)[0]

def delete_office(office_id):
    import json
    from datetime import datetime
    with connect() as c:
        office=c.execute("SELECT * FROM offices WHERE id=? AND active=1",(office_id,)).fetchone()
        if not office: return None
        data={"office":dict(office),"users":[],"properties":[],"clients":[],"visits":[],"notes":[],"chat_messages":[]}
        for table in ("users","properties","clients","visits","notes","chat_messages"):
            data[table]=[dict(r) for r in c.execute(f"SELECT * FROM {table} WHERE office_id=?",(office_id,)).fetchall()]
        stamp=jdatetime.datetime.now().strftime("%Y-%m-%d_%H-%M")
        safe="".join(ch for ch in office["name"] if ch.isalnum() or ch in " -_").strip()[:60] or "دفتر"
        path=ARCHIVE_DIR / f"{safe}_{stamp}.json"
        path.write_text(json.dumps(data,ensure_ascii=False,indent=2,default=str),encoding="utf-8")
        c.execute("INSERT OR REPLACE INTO deleted_offices(id,name,deleted_at,archive_path) VALUES(?,?,?,?)",(office_id,office["name"],now_iso(),str(path)))
        c.execute("UPDATE offices SET active=0,deleted_at=? WHERE id=?",(now_iso(),office_id))
        c.execute("UPDATE users SET active=0 WHERE office_id=? AND role!='super_admin'",(office_id,))
        c.execute("UPDATE licenses SET revoked=1 WHERE office_id=?",(office_id,))
        for table in ("properties","clients","visits","notes","history","chat_messages"):
            c.execute(f"DELETE FROM {table} WHERE office_id=?",(office_id,))
    return str(path)

def deleted_offices():
    with connect() as c:
        return [dict(r) for r in c.execute("SELECT * FROM deleted_offices ORDER BY deleted_at DESC").fetchall()]

def add_history(office_id, entity_type, entity_id, user_id, action):
    with connect() as c:
        c.execute("INSERT INTO history(office_id,entity_type,entity_id,user_id,action,created_at) VALUES(?,?,?,?,?,?)",
                  (office_id,entity_type,entity_id,user_id,action,now_iso()))

def add_property(office_id,user_id,data):
    keys=("property_type","deal_type","address","area","price","deposit","rent","owner_name","owner_phone","status","fields_json","description","photo_file_id")
    vals=[data.get(k) for k in keys]
    with connect() as c:
        cur=c.execute("""INSERT INTO properties(office_id,created_by,property_type,deal_type,address,area,price,deposit,rent,owner_name,owner_phone,status,fields_json,description,photo_file_id,created_at,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (office_id,user_id,*vals,now_iso(),now_iso()))
        pid=cur.lastrowid
    add_history(office_id,"property",pid,user_id,"ثبت فایل")
    return pid

def add_client(office_id,user_id,data):
    with connect() as c:
        cur=c.execute("""INSERT INTO clients(office_id,created_by,name,phone,property_type,deal_type,budget,area_min,area_max,location,required_json,need_date,threshold,source,stage,notes,created_at,updated_at,last_followup)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (office_id,user_id,data["name"],data.get("phone",""),data["property_type"],data["deal_type"],data["budget"],
         data.get("area_min"),data.get("area_max"),data["location"],data.get("required_json","{}"),data.get("need_date",""),
         data.get("threshold",70),data.get("source",""),data.get("stage","جدید"),data.get("notes",""),now_iso(),now_iso(),data.get("last_followup")))
        cid=cur.lastrowid
    add_history(office_id,"client",cid,user_id,"ثبت مشتری")
    return cid

def get_fields(property_type, deal_type):
    with connect() as c:
        rows=c.execute("""SELECT * FROM property_fields WHERE enabled=1 AND
          (property_type='*' OR property_type=?) AND (deal_type='*' OR deal_type=?)
          ORDER BY sort_order,id""",(property_type,deal_type)).fetchall()
    return [dict(r) for r in rows]

def get_weights(property_type):
    with connect() as c:
        rows=c.execute("SELECT field_key,weight FROM match_weights WHERE property_type=?",(property_type,)).fetchall()
    return {r["field_key"]:float(r["weight"]) for r in rows}

def office_properties(office_id):
    with connect() as c:
        return [dict(r) for r in c.execute("SELECT * FROM properties WHERE office_id=? ORDER BY id DESC",(office_id,)).fetchall()]

def office_clients(office_id):
    with connect() as c:
        return [dict(r) for r in c.execute("SELECT * FROM clients WHERE office_id=? ORDER BY id DESC",(office_id,)).fetchall()]

def get_property(office_id,pid):
    with connect() as c:
        r=c.execute("SELECT * FROM properties WHERE office_id=? AND id=?",(office_id,pid)).fetchone()
    return dict(r) if r else None

def get_client(office_id,cid):
    with connect() as c:
        r=c.execute("SELECT * FROM clients WHERE office_id=? AND id=?",(office_id,cid)).fetchone()
    return dict(r) if r else None

def assign_entity(office_id, entity_type, entity_id, user_id):
    table="properties" if entity_type=="property" else "clients"
    with connect() as c:
        cur=c.execute(f"UPDATE {table} SET assigned_to=?,updated_at=? WHERE office_id=? AND id=?",(user_id,now_iso(),office_id,entity_id))
    return cur.rowcount>0

def add_note(office_id,entity_type,entity_id,user_id,body):
    with connect() as c:
        c.execute("INSERT INTO notes(office_id,entity_type,entity_id,user_id,body,created_at) VALUES(?,?,?,?,?,?)",
                  (office_id,entity_type,entity_id,user_id,body,now_iso()))
    add_history(office_id,entity_type,entity_id,user_id,"افزودن یادداشت")

def entity_notes(office_id,entity_type,entity_id):
    with connect() as c:
        return [dict(r) for r in c.execute("SELECT * FROM notes WHERE office_id=? AND entity_type=? AND entity_id=? ORDER BY id DESC",(office_id,entity_type,entity_id)).fetchall()]

def add_visit(office_id,pid,cid,user_id,visit_at,result,notes):
    with connect() as c:
        cur=c.execute("INSERT INTO visits(office_id,property_id,client_id,created_by,visit_at,result,notes) VALUES(?,?,?,?,?,?,?)",
                      (office_id,pid,cid,user_id,visit_at,result,notes))
    add_history(office_id,"property",pid,user_id,f"ثبت بازدید مشتری {cid}")
    return cur.lastrowid

def chat_add(office_id,telegram_id,sender,body,related_type="",related_id=None):
    chat_db_init(office_id)
    with connect(office_db_path(office_id)) as c:
        c.execute("INSERT INTO chat_messages(office_id,telegram_id,sender,body,related_type,related_id,month_key,created_at) VALUES(?,?,?,?,?,?,?,?)",
                  (office_id,telegram_id,sender,body,related_type,related_id,month_key(),now_iso()))

def chat_month(office_id,key=None):
    chat_db_init(office_id)
    key=key or month_key()
    with connect(office_db_path(office_id)) as c:
        return [dict(r) for r in c.execute("SELECT * FROM chat_messages WHERE office_id=? AND month_key=? ORDER BY id",(office_id,key)).fetchall()]

def chat_months(office_id):
    chat_db_init(office_id)
    with connect(office_db_path(office_id)) as c:
        return [r["month_key"] for r in c.execute("SELECT DISTINCT month_key FROM chat_messages WHERE office_id=? ORDER BY month_key DESC",(office_id,)).fetchall()]

def archive_old_chats():
    # Runs once a day; only archives if stored month differs from current month.
    current=month_key()
    results=[]
    with connect() as c:
        office_ids=[r["id"] for r in c.execute("SELECT id FROM offices WHERE active=1").fetchall()]
    for oid in office_ids:
        chat_db_init(oid)
        with connect(office_db_path(oid)) as chat:
            keys=[r["month_key"] for r in chat.execute("SELECT DISTINCT month_key FROM chat_messages WHERE month_key<>?",(current,)).fetchall()]
            for key in keys:
                rows=[dict(r) for r in chat.execute("SELECT * FROM chat_messages WHERE month_key=? ORDER BY id",(key,)).fetchall()]
                label=month_label(key)
                path=DATA_DIR / f"چت_دفتر_{oid}_{label}.txt"
                lines=[f"آرشیو چت دفتر {oid} — {label}","="*40]
                for r in rows:
                    lines.append(f"[{r['created_at']}] {r['sender']}: {r['body']}"+(f" | مرتبط: {r['related_type']} #{r['related_id']}" if r.get("related_id") else ""))
                path.write_text("\\n".join(lines),encoding="utf-8")
                chat.execute("DELETE FROM chat_messages WHERE month_key=?",(key,))
                results.append((oid,key,str(path)))
    return results

def all_office_data(office_id):
    with connect() as c:
        result={}
        for table in ("offices","users","licenses","properties","clients","visits","notes","history"):
            if table=="offices":
                rows=c.execute("SELECT * FROM offices WHERE id=?",(office_id,)).fetchall()
            elif table=="licenses":
                rows=c.execute("SELECT * FROM licenses WHERE office_id=?",(office_id,)).fetchall()
            else:
                rows=c.execute(f"SELECT * FROM {table} WHERE office_id=?",(office_id,)).fetchall()
            result[table]=[dict(r) for r in rows]
    result["chat_messages"]=chat_month(office_id)
    return result
