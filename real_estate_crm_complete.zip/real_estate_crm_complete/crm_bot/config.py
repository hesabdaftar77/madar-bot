import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("DATA_DIR", str(BASE_DIR / "data"))).resolve()
DATA_DIR.mkdir(parents=True, exist_ok=True)
ARCHIVE_DIR = BASE_DIR / "دفاتر حذف‌شده"
ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
SUPER_LICENSE = os.getenv("SUPER_LICENSE", "")
RESET_SUPER_LICENSE = os.getenv("RESET_SUPER_LICENSE", "0").strip()
BACKUP_CHANNEL_ID = os.getenv("BACKUP_CHANNEL_ID", "").strip()
TIMEZONE = os.getenv("TZ", "Asia/Tehran").strip()
