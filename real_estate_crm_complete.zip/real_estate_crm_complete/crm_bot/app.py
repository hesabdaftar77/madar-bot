import asyncio, json, logging, os, re, tempfile
from functools import wraps
from pathlib import Path
from datetime import datetime, time
from zoneinfo import ZoneInfo
import jdatetime
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.constants import ChatType
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ConversationHandler, ContextTypes, filters
from .config import BOT_TOKEN, DATA_DIR, BACKUP_CHANNEL_ID, TIMEZONE
from . import db
from .matching import score_match
from .import_export import IMPORT_GUIDE, export_all, parse_csv

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
logging.getLogger("httpx").setLevel(logging.WARNING)
log=logging.getLogger("crm")

# گفتگوها و فرم‌ها در user_data نگهداری می‌شوند.
WAIT_LICENSE, WAIT_NAME, WAIT_OFFICE_NAME, WAIT_SUPER_PASSWORD, WAIT_NEW_PASSWORD, WAIT_NEW_PASSWORD_CONFIRM = range(6)
WAIT_PROPERTY, WAIT_CLIENT, WAIT_NOTE, WAIT_ASSIGN, WAIT_VISIT, WAIT_IMPORT = range(6,12)

MAIN_MENU=[
 ["➕ فایل جدید","👤 مشتری جدید"],
 ["🔍 تطبیق","📞 امروز"],
 ["📊 گزارش","💬 چت روم"],
 ["📁 آرشیو چت‌ها","📥 راهنمای درون‌ریزی"],
 ["🔎 جست‌وجو","📋 کاربران دفتر"],
]
SUPER_MENU=[
 ["🏢 ساخت دفتر","🏢 فهرست دفترها"],
 ["👥 کاربران دفتر","🗑 حذف کاربر"],
 ["🗑 حذف دفتر","🗄 دفاتر حذف‌شده"],
 ["📤 خروجی کامل اطلاعات","📥 درون‌ریزی انبوه"],
 ["🔑 تغییر رمز","🚪 خروج از پنل"],
]

def kb(rows, resize=True):
    return ReplyKeyboardMarkup([[KeyboardButton(x) for x in row] for row in rows],resize_keyboard=resize,is_persistent=True)

def user_menu(role):
    return kb(SUPER_MENU if role=="super_admin" else MAIN_MENU)

def guarded(*roles):
    def deco(fn):
        @wraps(fn)
        async def wrapped(update, context, *args, **kwargs):
            uid=update.effective_user.id if update.effective_user else None
            u=context.user_data.get("auth")
            if not u or (roles and u.get("role") not in roles):
                # حساب‌های غیرمجاز هیچ اطلاعات داخلی دریافت نمی‌کنند.
                if u is None and context.user_data.get("super_hidden"):
                    return
                if update.callback_query:
                    await update.callback_query.answer()
                elif update.message:
                    await update.message.reply_text("برای استفاده، ابتدا /start را بفرستید.")
                return
            if u["role"]!="super_admin":
                real=db.get_user(uid)
                if not real or real["office_id"]!=u.get("office_id") or real["role"]!=u["role"]:
                    context.user_data.pop("auth",None)
                    if update.message: await update.message.reply_text("دسترسی شما غیرفعال شده است.")
                    return
            return await fn(update,context,*args,**kwargs)
        return wrapped
    return deco

def is_super(context):
    return context.user_data.get("auth",{}).get("role")=="super_admin"

def office_id(context):
    return context.user_data.get("auth",{}).get("office_id")

def auth_user(context):
    return context.user_data.get("auth",{})

async def send_long(message, text, **kwargs):
    # Telegram limit is 4096; split at line boundaries.
    chunks=[]
    while len(text)>3800:
        cut=text.rfind("\\n",0,3800)
        if cut<500: cut=3800
        chunks.append(text[:cut]); text=text[cut:].lstrip()
    if text: chunks.append(text)
    for chunk in chunks:
        await message.reply_text(chunk,**kwargs)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message: return
    context.user_data.clear()
    u=db.get_user(update.effective_user.id)
    if u:
        context.user_data["auth"]=u
        await update.message.reply_text("خوش آمدید. منوی دفتر شما آماده است.",reply_markup=user_menu(u["role"]))
        return
    await update.message.reply_text("برای ورود، لایسنس خود را ارسال کنید. اگر حساب سازنده هستید، رمز سازنده را وارد کنید.")
    context.user_data["state"]="license"

async def receive_text(update,context):
    if not update.message or not update.message.text: return
    text=update.message.text.strip()
    state=context.user_data.get("state")
    if state=="license":
        # سازنده با رمز دائمی؛ در پاسخ هیچ‌گاه مقدار رمز بازتاب داده نمی‌شود.
        if db.password_check(text):
            context.user_data.clear()
            context.user_data["auth"]={"role":"super_admin","office_id":None,"user_id":None,"telegram_id":update.effective_user.id,"full_name":"مدیریت سامانه"}
            await update.message.reply_text("ورود انجام شد.",reply_markup=user_menu("super_admin"))
            return
        result=db.consume_license(text,update.effective_user.id,update.effective_user.full_name or "کاربر")
        if not result:
            await update.message.reply_text("لایسنس نامعتبر است")
            return
        u=db.get_user(update.effective_user.id)
        context.user_data.clear(); context.user_data["auth"]=u
        await update.message.reply_text("ورود با موفقیت انجام شد.",reply_markup=user_menu(u["role"]))
        return
    if state=="super_new_password":
        context.user_data["new_password"]=text
        context.user_data["state"]="super_confirm_password"
        try: await update.message.delete()
        except Exception: pass
        await update.message.reply_text("رمز جدید را دوباره وارد کنید تا تأیید شود.")
        return
    if state=="super_confirm_password":
        new=context.user_data.pop("new_password","")
        try: await update.message.delete()
        except Exception: pass
        context.user_data.pop("state",None)
        if not new or new!=text:
            await update.message.reply_text("رمزها یکسان نیستند. از دکمه تغییر رمز دوباره شروع کنید.",reply_markup=user_menu("super_admin"))
            return
        db.change_super_password(new)
        await update.message.reply_text("رمز سازنده تغییر کرد.",reply_markup=user_menu("super_admin"))
        return
    if state=="new_office":
        name=text[:100]
        oid,token=db.create_office(name,auth_user(context).get("telegram_id",update.effective_user.id))
        context.user_data.pop("state",None)
        await update.message.reply_text(f"دفتر ساخته شد: {name}\\nشناسه دفتر: {oid}\\nلایسنس مدیر دفتر (فقط یک بار قابل استفاده):\\n`{token}`",parse_mode="Markdown",reply_markup=user_menu("super_admin"))
        return
    if state=="new_property":
        await property_form_text(update,context,text); return
    if state=="new_client":
        await client_form_text(update,context,text); return
    if state=="note":
        data=context.user_data.pop("note_target",None); context.user_data.pop("state",None)
        if data:
            db.add_note(office_id(context),data["type"],data["id"],auth_user(context).get("user_id") or 0,text)
            await update.message.reply_text("یادداشت ذخیره شد.",reply_markup=user_menu(auth_user(context)["role"]))
        return
    if state=="assign":
        await assign_text(update,context,text); return
    if state=="visit":
        await visit_text(update,context,text); return
    if state=="import":
        await update.message.reply_text("برای درون‌ریزی، فایل CSV را به‌صورت سند ارسال کنید.")
        return
    if context.user_data.get("chat_mode"):
        if text=="🚪 خروج از چت روم":
            context.user_data.pop("chat_mode",None)
            await update.message.reply_text("از چت روم خارج شدید.",reply_markup=user_menu(auth_user(context)["role"]))
            return
        u=auth_user(context)
        db.chat_add(u["office_id"],update.effective_user.id,u.get("full_name",update.effective_user.full_name),text)
        await update.message.reply_text("پیام در چت روم دفتر ذخیره شد و برای اعضا ارسال می‌شود.")
        with db.connect() as c:
            members=c.execute("SELECT telegram_id FROM users WHERE office_id=? AND active=1 AND telegram_id<>?",(u["office_id"],update.effective_user.id)).fetchall()
        for member in members:
            try: await context.bot.send_message(member["telegram_id"],f"💬 {u.get('full_name',update.effective_user.full_name)}:\\n{text}")
            except Exception: pass
        return
    await route_menu(update,context,text)

async def route_menu(update,context,text):
    role=auth_user(context).get("role")
    if role=="super_admin":
        await super_menu(update,context,text); return
    if text=="➕ فایل جدید":
        context.user_data["state"]="new_property"
        context.user_data["property_data"]={}
        context.user_data["property_step"]=0
        await ask_property_field(update,context); return
    if text=="👤 مشتری جدید":
        context.user_data["state"]="new_client"; context.user_data["client_data"]={}; context.user_data["client_step"]=0
        await ask_client_field(update,context); return
    if text=="🔍 تطبیق": await show_matches(update,context); return
    if text=="📞 امروز": await today_tasks(update,context); return
    if text=="📊 گزارش": await report(update,context); return
    if text=="💬 چت روم": await open_chat(update,context); return
    if text=="📁 آرشیو چت‌ها": await chat_archive_menu(update,context); return
    if text=="📥 راهنمای درون‌ریزی": await update.message.reply_text("درون‌ریزی انبوه فقط در پنل سازنده فعال است.\\n"+IMPORT_GUIDE); return
    if text=="🔎 جست‌وجو":
        await update.message.reply_text("برای جست‌وجو دستور /فایل شماره یا /مشتری نام را بفرستید."); return
    if text=="📋 کاربران دفتر":
        users=db.list_users(office_id(context))
        body="\\n".join(f"#{x['id']} — {x['full_name']} ({'مدیر دفتر' if x['role']=='office_admin' else 'مشاور'})" for x in users) or "کاربری ثبت نشده است."
        await send_long(update.message,body); return
    if text=="برای من":
        await update.message.reply_text("برای تخصیص، ابتدا فایل/مشتری را با دستور مربوطه باز کنید."); return
    await update.message.reply_text("گزینه را از منو انتخاب کنید.",reply_markup=user_menu(role))

async def super_menu(update,context,text):
    if text=="🏢 ساخت دفتر":
        context.user_data["state"]="new_office"
        await update.message.reply_text("نام دفتر را بفرستید.")
    elif text=="🏢 فهرست دفترها":
        offices=db.list_offices()
        if not offices: await update.message.reply_text("دفتری ثبت نشده است."); return
        for o in offices:
            await update.message.reply_text(f"🏢 #{o['id']} — {o['name']} — ساخته‌شده: {o['created_at']}")
    elif text=="👥 کاربران دفتر":
        offices=db.list_offices()
        await update.message.reply_text("شناسه دفتر را وارد کنید: "+", ".join(f"{o['id']}:{o['name']}" for o in offices) if offices else "دفتری وجود ندارد.")
        context.user_data["state"]="super_list_users"
    elif context.user_data.get("state")=="super_list_users":
        try: oid=int(text)
        except: await update.message.reply_text("شناسه دفتر باید عدد باشد."); return
        users=db.list_users(oid)
        await send_long(update.message,"\\n".join(f"#{u['id']} {u['full_name']} — {u['role']}" for u in users) or "کاربری وجود ندارد.")
        context.user_data.pop("state",None)
    elif text=="🗑 حذف کاربر":
        await update.message.reply_text("شناسه کاربر را وارد کنید. حساب سازنده قابل حذف نیست.")
        context.user_data["state"]="super_delete_user"
    elif context.user_data.get("state")=="super_delete_user":
        try: db.remove_user(int(text))
        except ValueError: await update.message.reply_text("شناسه نامعتبر است."); return
        context.user_data.pop("state",None); await update.message.reply_text("اگر کاربر مجاز وجود داشت، دسترسی او قطع شد.")
    elif text=="🗑 حذف دفتر":
        await update.message.reply_text("شناسه دفتر را برای حذف دائمی داده‌های فعال و ساخت آرشیو وارد کنید.")
        context.user_data["state"]="super_delete_office"
    elif context.user_data.get("state")=="super_delete_office":
        try: result=db.delete_office(int(text))
        except ValueError: result=None
        context.user_data.pop("state",None)
        await update.message.reply_text("دفتر حذف شد و آرشیو ساخته شد." if result else "دفتر پیدا نشد.")
    elif text=="🗄 دفاتر حذف‌شده":
        rows=db.deleted_offices()
        await send_long(update.message,"\\n".join(f"#{r['id']} — {r['name']} — {r['archive_path']}" for r in rows) or "آرشیوی ثبت نشده است.")
    elif text=="📤 خروجی کامل اطلاعات":
        path=export_all(DATA_DIR)
        with open(path,"rb") as f: await update.message.reply_document(f,filename=path.name,caption="خروجی کامل اطلاعات سامانه")
    elif text=="📥 درون‌ریزی انبوه":
        context.user_data["state"]="import"
        await update.message.reply_text(IMPORT_GUIDE+"\\nفایل CSV را به‌صورت سند ارسال کنید.")
    elif text=="🔑 تغییر رمز":
        context.user_data["state"]="super_current_password"
        await update.message.reply_text("رمز فعلی را وارد کنید. پیام ورودی حذف خواهد شد.")
    elif context.user_data.get("state")=="super_current_password":
        ok=db.password_check(text)
        try: await update.message.delete()
        except Exception: pass
        if ok:
            context.user_data["state"]="super_new_password"
            await update.message.reply_text("رمز جدید را وارد کنید؛ پیام ورودی حذف می‌شود.")
        else:
            await update.message.reply_text("لایسنس نامعتبر است",reply_markup=user_menu("super_admin"))
            context.user_data.pop("state",None)
    elif text=="🚪 خروج از پنل":
        context.user_data.clear()
        await update.message.reply_text("برای ورود، /start را بفرستید.",reply_markup=ReplyKeyboardMarkup([["/start"]],resize_keyboard=True))
    else:
        await update.message.reply_text("گزینه را از پنل انتخاب کنید.",reply_markup=user_menu("super_admin"))

def prop_steps():
    return [
      ("property_type","نوع ملک",["آپارتمان","ویلا/خانه","تجاری","اداری","زمین/باغ","صنعتی","کشاورزی"],True),
      ("deal_type","نوع معامله",["خرید و فروش","رهن و اجاره","پیش‌فروش","مشارکت در ساخت"],True),
      ("address","محله/آدرس",None,True),("area","متراژ (متر)",None,True),
      ("owner_name","نام مالک",None,True),("owner_phone","شماره مالک",None,True),
      ("price","قیمت کل (تومان)",None,False),("deposit","رهن (تومان)",None,False),("rent","اجاره ماهانه (تومان)",None,False),
      ("status","وضعیت فایل",["فعال","معامله‌شده","منقضی"],True),("description","توضیحات",None,False)
    ]

async def ask_property_field(update,context):
    data=context.user_data["property_data"]; steps=prop_steps(); i=context.user_data["property_step"]
    if i>=len(steps):
        # Dynamic property-specific fields are prompted from the settings table.
        dynamic=db.get_fields(data["property_type"],data["deal_type"])
        extras=[f for f in dynamic if f["field_key"] not in {s[0] for s in steps} and not f["field_key"].startswith("client_") and f["field_key"]!="business_type"]
        context.user_data["property_extras"]=extras; context.user_data["property_extra_step"]=0
        await ask_property_extra(update,context); return
    key,label,options,required=steps[i]
    if key=="price" and data.get("deal_type")=="رهن و اجاره": context.user_data["property_step"]+=1; await ask_property_field(update,context); return
    if key in ("deposit","rent") and data.get("deal_type")!="رهن و اجاره": context.user_data["property_step"]+=1; await ask_property_field(update,context); return
    markup=kb([[x for x in options]]+[["رد کردن"]] if options else [["رد کردن"]])
    if required and not options: markup=None
    await update.message.reply_text(f"{label}{' (الزامی)' if required else ' (اختیاری)'} را وارد کنید.",reply_markup=markup)

async def ask_property_extra(update,context):
    extras=context.user_data.get("property_extras",[]); i=context.user_data.get("property_extra_step",0)
    if i>=len(extras):
        data=context.user_data["property_data"]
        # Essential validation for transaction type.
        if data.get("deal_type")=="خرید و فروش" and not data.get("price"):
            await update.message.reply_text("قیمت کل الزامی است. قیمت را وارد کنید.")
            context.user_data["property_force_price"]=True; return
        if data.get("deal_type")=="رهن و اجاره" and (not data.get("deposit") or not data.get("rent")):
            await update.message.reply_text("رهن و اجاره هر دو الزامی‌اند. مقدار رهن را وارد کنید.")
            context.user_data["property_force_money"]="deposit"; return
        pid=db.add_property(office_id(context),auth_user(context).get("id",0),data)
        context.user_data.pop("state",None)
        await update.message.reply_text(f"✅ فایل با شماره {pid} ثبت شد.",reply_markup=user_menu(auth_user(context)["role"]))
        # Two-way matching alert.
        clients=db.office_clients(office_id(context)); prop=db.get_property(office_id(context),pid); matches=[]
        for cl in clients:
            score,miss=score_match(cl,prop)
            if score is not None and score>=int(cl["threshold"]): matches.append((cl,score))
        if matches: await update.message.reply_text("👥 مشتریان بالای آستانه برای این فایل:\\n"+ "\\n".join(f"مشتری #{cl['id']} — {cl['name']} — {score}٪" for cl,score in matches[:20]))
        return
    f=extras[i]
    options=(f.get("options") or "").split("|") if f.get("options") else None
    markup=kb([options]+[["رد کردن"]]) if options else kb([["رد کردن"]])
    await update.message.reply_text(f"{f['label']}{' (الزامی)' if f['required'] else ' (اختیاری)'} را وارد کنید.",reply_markup=markup if not f["required"] else (kb([options]) if options else None))

async def property_form_text(update,context,text):
    data=context.user_data["property_data"]
    if context.user_data.pop("property_force_price",False):
        data["price"]=text; await ask_property_extra(update,context); return
    force=context.user_data.pop("property_force_money",None)
    if force:
        data[force]=text; context.user_data["property_force_money"]="rent" if force=="deposit" else None
        if force=="deposit": await update.message.reply_text("مبلغ اجاره را وارد کنید.")
        else: await ask_property_extra(update,context)
        return
    steps=prop_steps(); i=context.user_data["property_step"]
    if i<len(steps):
        key,label,options,required=steps[i]
        if text=="رد کردن":
            if required: await update.message.reply_text("این فیلد الزامی است و نمی‌تواند خالی بماند."); return
            data[key]=""
        else:
            if options and text not in options: await update.message.reply_text("یکی از گزینه‌های نمایش‌داده‌شده را انتخاب کنید."); return
            if key in ("area","price","deposit","rent"):
                try: data[key]=float(text.replace(",",""))
                except: await update.message.reply_text("لطفاً عدد معتبر وارد کنید."); return
            else: data[key]=text
        context.user_data["property_step"]+=1; await ask_property_field(update,context); return
    extras=context.user_data.get("property_extras",[]); j=context.user_data.get("property_extra_step",0)
    if j<len(extras):
        f=extras[j]
        if text=="رد کردن":
            if f["required"]: await update.message.reply_text("این فیلد الزامی است."); return
            value=""
        else: value=text
        data.setdefault("fields",{})[f["field_key"]]=value
        # Core columns are kept normalized, extra fields in JSON.
        if f["field_key"] in ("deposit","rent","price","total_price"):
            try: data["price" if f["field_key"]=="total_price" else f["field_key"]]=float(value.replace(",",""))
            except: pass
        context.user_data["property_extra_step"]+=1; await ask_property_extra(update,context)

def client_steps():
    return [
      ("name","نام مشتری",None,True),("phone","شماره تماس",None,False),
      ("property_type","نوع ملک",["آپارتمان","ویلا/خانه","تجاری","اداری","زمین/باغ","صنعتی","کشاورزی"],True),
      ("deal_type","نوع معامله",["خرید و فروش","رهن و اجاره","پیش‌فروش","مشارکت در ساخت"],True),
      ("budget","بودجه (تومان)",None,True),("location","محدوده",None,True),
      ("area_min","حداقل متراژ",None,False),("area_max","حداکثر متراژ",None,False),
      ("required_text","امکانات/شرط‌های ضروری (مثلاً parking=دارد)",None,False),
      ("need_date","تاریخ نیاز",None,False),("threshold","آستانه تطبیق: ۴۰ تا ۱۰۰",["۴۰","۵۰","۶۰","۷۰","۸۰","۹۰","۱۰۰"],False),
      ("source","منبع جذب",["دیوار","معرفی","مراجعه"],False),("stage","مرحله مشتری",["جدید","بازدید","مذاکره","قرارداد"],True),
      ("notes","یادداشت",None,False)
    ]

async def ask_client_field(update,context):
    steps=client_steps(); i=context.user_data["client_step"]
    if i>=len(steps):
        d=context.user_data["client_data"]
        req={}
        raw=d.pop("required_text","")
        for item in raw.split(","):
            if "=" in item:
                k,v=item.split("=",1); req[k.strip()]=v.strip()
        d["required_json"]=json.dumps(req,ensure_ascii=False)
        # Round typed threshold to nearest ten, constrained 40..100.
        try: th=int(str(d.get("threshold",70)).translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹","0123456789")))
        except: th=70
        th=max(40,min(100,int(round(th/10)*10))); d["threshold"]=th
        cid=db.add_client(office_id(context),auth_user(context).get("id",0),d)
        context.user_data.pop("state",None)
        await update.message.reply_text(f"✅ مشتری #{cid} ثبت شد. آستانه تطبیق: {th}٪",reply_markup=user_menu(auth_user(context)["role"]))
        await show_client_matches(update,context,cid)
        return
    key,label,options,required=steps[i]
    if options:
        await update.message.reply_text(f"{label}{' (الزامی)' if required else ' (اختیاری)'} را انتخاب کنید.",reply_markup=kb([options]+([] if required else [["رد کردن"]])))
    else:
        await update.message.reply_text(f"{label}{' (الزامی)' if required else ' (اختیاری)'} را وارد کنید.",reply_markup=None if required else kb([["رد کردن"]]))

async def client_form_text(update,context,text):
    steps=client_steps(); i=context.user_data["client_step"]; key,label,options,required=steps[i]; d=context.user_data["client_data"]
    if text=="رد کردن":
        if required: await update.message.reply_text("این فیلد الزامی است."); return
        d[key]=""
    else:
        if options and text not in options:
            # Allow Arabic/Persian numerals for threshold.
            if key=="threshold":
                pass
            else: await update.message.reply_text("یکی از گزینه‌های نمایش‌داده‌شده را انتخاب کنید."); return
        if key in ("budget","area_min","area_max"):
            try: d[key]=float(text.translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹","0123456789")).replace(",",""))
            except: await update.message.reply_text("لطفاً عدد معتبر وارد کنید."); return
        elif key=="threshold":
            try:
                n=int(text.translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹","0123456789")))
                n=max(40,min(100,int(round(n/10)*10))); d[key]=n
            except: d[key]=70
        else: d[key]=text
    context.user_data["client_step"]+=1; await ask_client_field(update,context)

async def show_client_matches(update,context,cid):
    client=db.get_client(office_id(context),cid)
    matches=[]
    for p in db.office_properties(office_id(context)):
        score,miss=score_match(client,p)
        if score is not None and score>=client["threshold"]: matches.append((p,score,miss))
    matches.sort(key=lambda x:x[1],reverse=True)
    if not matches: await update.message.reply_text("فعلاً فایل منطبق با آستانه مشتری پیدا نشد."); return
    lines=["🔍 فایل‌های منطبق:"]
    for p,s,m in matches[:15]:
        lines.append(f"{'🟢' if s>=80 else '🟡'} فایل #{p['id']} — {p['property_type']} — {p['address']} — {s}٪"+(f"\\nمغایرت: {', '.join(m[:3])}" if s<80 and m else ""))
    await send_long(update.message,"\\n".join(lines))

@guarded("office_admin","consultant")
async def show_matches(update,context):
    clients=db.office_clients(office_id(context)); props=db.office_properties(office_id(context))
    out=[]
    for cl in clients:
        matches=[]
        for p in props:
            s,m=score_match(cl,p)
            if s is not None and s>=cl["threshold"]: matches.append((p,s,m))
        matches.sort(key=lambda x:x[1],reverse=True)
        if matches:
            out.append(f"👤 مشتری #{cl['id']} {cl['name']} (آستانه {cl['threshold']}٪)")
            out.extend(f"{'🟢' if s>=80 else '🟡'} فایل #{p['id']} {p['address']} — {s}٪"+(f" | مغایرت: {', '.join(m[:2])}" if s<80 and m else "") for p,s,m in matches[:5])
    await send_long(update.message,"\\n".join(out) or "تطبیق بالای آستانه‌ای پیدا نشد.")

@guarded("office_admin","consultant")
async def today_tasks(update,context):
    from .db import connect
    oid=office_id(context)
    with connect() as c:
        overdue=c.execute("SELECT id,name,phone,last_followup FROM clients WHERE office_id=? AND (last_followup IS NULL OR last_followup='')",(oid,)).fetchall()
        old=c.execute("SELECT id,name,phone,updated_at FROM clients WHERE office_id=? AND updated_at < datetime('now','-3 days') AND stage NOT IN ('قرارداد')",(oid,)).fetchall()
    lines=["📞 پیگیری‌های امروز"]
    lines += [f"مشتری #{r['id']} — {r['name']} — {r['phone'] or 'بدون شماره'}" for r in overdue[:30]]
    if old: lines.append("\\n⚠️ مشتریان بدون پیگیری اخیر:"); lines += [f"#{r['id']} {r['name']}" for r in old[:20]]
    await send_long(update.message,"\\n".join(lines))

@guarded("office_admin","consultant")
async def report(update,context):
    oid=office_id(context); props=db.office_properties(oid); clients=db.office_clients(oid)
    with db.connect() as c:
        visits=c.execute("SELECT COUNT(*) n FROM visits WHERE office_id=?",(oid,)).fetchone()["n"]
        deals=c.execute("SELECT COUNT(*) n FROM properties WHERE office_id=? AND status='معامله‌شده'",(oid,)).fetchone()["n"]
    types={}
    for p in props: types[p["property_type"]]=types.get(p["property_type"],0)+1
    sources={}
    for cl in clients: sources[cl.get("source") or "نامشخص"]=sources.get(cl.get("source") or "نامشخص",0)+1
    msg=f"📊 گزارش دفتر\\nفایل‌ها: {len(props)}\\nمشتری‌ها: {len(clients)}\\nبازدیدها: {visits}\\nمعامله‌شده: {deals}\\n\\nتفکیک نوع ملک:\\n"
    msg+="\\n".join(f"{k}: {v}" for k,v in types.items()) or "بدون فایل"
    msg+="\\n\\nمنبع جذب مشتری:\\n"+"\\n".join(f"{k}: {v}" for k,v in sources.items())
    await send_long(update.message,msg)

@guarded("office_admin","consultant")
async def open_chat(update,context):
    context.user_data["chat_mode"]=True
    await update.message.reply_text("💬 چت روم دفتر — پیام‌های ماه شمسی جاری\\nبرای خروج دکمه زیر را بزنید.",reply_markup=kb([["🚪 خروج از چت روم"]]))
    rows=db.chat_month(office_id(context))
    if not rows: await update.message.reply_text("هنوز پیامی در این ماه ثبت نشده است.")
    else:
        await send_long(update.message,"\\n".join(f"[{r['created_at']}] {r['sender']}: {r['body']}" for r in rows))

@guarded("office_admin","consultant")
async def chat_archive_menu(update,context):
    months=db.chat_months(office_id(context))
    if not months: await update.message.reply_text("آرشیوی موجود نیست."); return
    buttons=[[InlineKeyboardButton(m,callback_data=f"archive:{m}")] for m in months]
    await update.message.reply_text("ماه موردنظر را انتخاب کنید:",reply_markup=InlineKeyboardMarkup(buttons))

async def callbacks(update,context):
    q=update.callback_query
    if not q: return
    await q.answer()
    data=q.data or ""
    if data.startswith("archive:"):
        u=auth_user(context)
        if not u or u.get("role") not in ("office_admin","consultant"): return
        key=data.split(":",1)[1]; rows=db.chat_month(u["office_id"],key)
        from .db import month_label
        path=DATA_DIR/f"آرشیو_چت_{u['office_id']}_{month_label(key)}.txt"
        path.write_text("\\n".join(f"[{r['created_at']}] {r['sender']}: {r['body']}" for r in rows),encoding="utf-8")
        with open(path,"rb") as f: await q.message.reply_document(f,filename=path.name)
        return
    if data.startswith("threshold:"):
        return

async def property_command(update,context):
    u=db.get_user(update.effective_user.id)
    if not u: return
    if not context.args:
        await update.message.reply_text("روش استفاده: /فایل شماره"); return
    try: pid=int(context.args[0])
    except: await update.message.reply_text("شماره فایل نامعتبر است."); return
    p=db.get_property(u["office_id"],pid)
    if not p: await update.message.reply_text("فایل پیدا نشد."); return
    await update.message.reply_text(f"فایل #{p['id']}\\nنوع: {p['property_type']} | معامله: {p['deal_type']}\\nآدرس: {p['address']}\\nمتراژ: {p['area']}\\nقیمت: {p['price']} | رهن: {p['deposit']} | اجاره: {p['rent']}\\nمالک: {p['owner_name']} — {p['owner_phone']}\\nوضعیت: {p['status']}\\nتوضیحات: {p['description']}")

async def client_command(update,context):
    u=db.get_user(update.effective_user.id)
    if not u: return
    name=" ".join(context.args).strip()
    if not name:
        await update.message.reply_text("روش استفاده: /مشتری نام"); return
    clients=db.office_clients(u["office_id"])
    found=[c for c in clients if name.casefold() in c["name"].casefold()]
    await send_long(update.message,"\\n".join(f"مشتری #{c['id']} — {c['name']} — {c['phone']} — {c['property_type']} — بودجه {c['budget']}" for c in found[:20]) or "مشتری پیدا نشد.")

async def match_command(update,context):
    u=db.get_user(update.effective_user.id)
    if not u: return
    await show_matches(update,context)

async def document_handler(update,context):
    u=auth_user(context)
    if not u or u.get("role")!="super_admin" or context.user_data.get("state")!="import":
        await update.message.reply_text("درون‌ریزی فقط در پنل سازنده مجاز است."); return
    doc=update.message.document
    if not doc or not doc.file_name.lower().endswith(".csv"):
        await update.message.reply_text("فقط فایل CSV با کدگذاری UTF-8 ارسال کنید."); return
    tgfile=await doc.get_file()
    content=await tgfile.download_as_bytearray()
    try: rows,headers=parse_csv(bytes(content))
    except Exception:
        await update.message.reply_text("خواندن CSV ناموفق بود؛ فایل باید UTF-8 باشد."); return
    await update.message.reply_text(f"فایل دریافت شد: {len(rows)} ردیف. ستون‌ها: {', '.join(headers)}\\nبرای امنیت و جلوگیری از ورود اشتباه، درون‌ریزی مستقیم در این نسخه غیرفعال است؛ از قالب راهنما استفاده و قبل از اعمال، خروجی پشتیبان بگیرید.")

async def monthly_archive_job(context):
    try:
        results=db.archive_old_chats()
        if BACKUP_CHANNEL_ID:
            for oid,key,path in results:
                try:
                    with open(path,"rb") as f:
                        await context.bot.send_document(chat_id=int(BACKUP_CHANNEL_ID),document=f,filename=Path(path).name,caption=f"آرشیو چت دفتر {oid} — {key}")
                except Exception as e: log.warning("ارسال بک‌آپ ناموفق بود: %s",type(e).__name__)
    except Exception as e: log.exception("خطا در آرشیو چت: %s",type(e).__name__)

async def property_form_error(update,context):
    if update.message: await update.message.reply_text("خطای ورودی. لطفاً دوباره تلاش کنید.")

def main():
    if not BOT_TOKEN:
        raise RuntimeError("متغیر TELEGRAM_BOT_TOKEN را در فایل .env تنظیم کنید.")
    db.init_db()
    app=Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start",start))
    app.add_handler(CommandHandler("فایل",property_command))
    app.add_handler(CommandHandler("مشتری",client_command))
    app.add_handler(CommandHandler("تطبیق",match_command))
    app.add_handler(CallbackQueryHandler(callbacks))
    app.add_handler(MessageHandler(filters.Document.ALL,document_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,receive_text))
    if app.job_queue:
        app.job_queue.run_daily(monthly_archive_job,time=time(hour=0,minute=10,tzinfo=ZoneInfo(TIMEZONE)),name="archive-monthly-chats")
    log.info("ربات CRM شروع شد.")
    app.run_polling(allowed_updates=Update.ALL_TYPES)
