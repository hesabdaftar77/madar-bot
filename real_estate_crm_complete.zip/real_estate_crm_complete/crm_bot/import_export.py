import json, csv, io, zipfile
from pathlib import Path
from .db import all_office_data, connect, MAIN_DB, DATA_DIR, now_iso

IMPORT_GUIDE = """راهنمای درون‌ریزی انبوه
۱) فایل CSV با کدگذاری UTF-8 بسازید.
۲) برای فایل‌ها از سرستون‌های زیر استفاده کنید:
code,property_type,deal_type,address,area,price,deposit,rent,owner_name,owner_phone,status,description
۳) برای مشتریان از این سرستون‌ها استفاده کنید:
code,name,phone,property_type,deal_type,budget,area_min,area_max,location,threshold,source,stage,notes
۴) هر ردیف یک رکورد است. شناسه‌ها باید یکتا باشند؛ قالب کد پیشنهادی: کدX_0001
۵) در ردیف اول نام ستون‌ها را دقیقاً مطابق نمونه بنویسید؛ فایل را CSV UTF-8 ذخیره کنید.
۶) فایل را به ربات ارسال کنید و نوع درون‌ریزی را انتخاب کنید.
۷) قبل از بارگذاری، از اطلاعات خروجی پشتیبان بگیرید.
نکته: درون‌ریزی فقط برای حساب سازنده فعال است. این نسخه از CSV پشتیبانی می‌کند؛ تصاویر با file_id تلگرام درون‌ریزی نمی‌شوند.
"""

def export_office(office_id, office_name, target_dir):
    target_dir=Path(target_dir); target_dir.mkdir(parents=True,exist_ok=True)
    data=all_office_data(office_id)
    path=target_dir / f"خروجی_{office_id}.json"
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2,default=str),encoding="utf-8")
    return path

def export_all(target_dir):
    target_dir=Path(target_dir); target_dir.mkdir(parents=True,exist_ok=True)
    with connect() as c:
        offices=[dict(r) for r in c.execute("SELECT * FROM offices").fetchall()]
    out=target_dir / "خروجی_کامل_سازنده.zip"
    with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED) as z:
        # SQLite is included as a restorable snapshot of the primary data.
        if MAIN_DB.exists(): z.write(MAIN_DB,"main.sqlite3")
        for office in offices:
            if office["active"]:
                data=all_office_data(office["id"])
                z.writestr(f"دفتر_{office['id']}_{office['name']}.json",json.dumps(data,ensure_ascii=False,indent=2,default=str))
                chat=DATA_DIR/f"office_{office['id']}_chat.sqlite3"
                if chat.exists(): z.write(chat,f"office_{office['id']}_chat.sqlite3")
    return out

def parse_csv(data_bytes):
    text=data_bytes.decode("utf-8-sig")
    reader=csv.DictReader(io.StringIO(text))
    return list(reader), reader.fieldnames or []
