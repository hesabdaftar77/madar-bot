import json, math
from .db import get_weights

def as_num(v):
    try: return float(v)
    except (TypeError,ValueError): return None

def score_match(client, prop):
    if client["property_type"] != prop["property_type"] or client["deal_type"] != prop["deal_type"]:
        return None, ["نوع ملک یا معامله متفاوت است"]
    if prop.get("status") != "فعال":
        return None, ["فایل فعال نیست"]
    required=json.loads(client.get("required_json") or "{}")
    fields=json.loads(prop.get("fields_json") or "{}")
    # شروط ضروری برای زمین و تجاری، در صورت تعیین مشتری، حذف قطعی‌اند.
    for key,val in required.items():
        if val and str(fields.get(key,"")).strip().casefold()!=str(val).strip().casefold():
            return None,[f"شرط ضروری «{key}» برقرار نیست"]
    weights=get_weights(client["property_type"])
    if not weights:
        weights={"budget":30,"location":25,"area":15,"features":20,"need_date":10}
    total=sum(weights.values()) or 100
    earned=0.0
    misses=[]
    budget=as_num(client.get("budget"))
    price=as_num(prop.get("price"))
    if client["deal_type"]=="رهن و اجاره":
        price=as_num(prop.get("deposit"))
        rent=as_num(prop.get("rent"))
        if budget is not None and price is not None:
            if price<=budget: earned+=weights.get("budget",0)
            elif price<=budget*1.1: earned+=weights.get("budget",0)*0.5; misses.append("رهن تا ۱۰٪ بالاتر از بودجه")
            else: misses.append("رهن بالاتر از بودجه")
        if rent is not None and rent>0:
            if client.get("area_max") and rent>budget*1.1: misses.append("اجاره نیازمند بررسی")
    else:
        if budget is not None and price is not None:
            if price<=budget: earned+=weights.get("budget",0)
            elif price<=budget*1.1: earned+=weights.get("budget",0)*0.5; misses.append("قیمت تا ۱۰٪ بالاتر از بودجه")
            else: misses.append("قیمت بالاتر از بودجه")
    location_weight=weights.get("location",0)
    c_loc=(client.get("location") or "").casefold()
    p_loc=(prop.get("address") or "").casefold()
    if c_loc and (c_loc in p_loc or p_loc in c_loc): earned+=location_weight
    else: misses.append("محدوده دقیقاً منطبق نیست")
    area_weight=weights.get("area",0)
    ca=as_num(client.get("area_min")); pa=as_num(prop.get("area"))
    if ca is None or pa is None: earned+=area_weight*0.5
    elif pa>=ca and (not client.get("area_max") or pa<=float(client["area_max"])*1.1): earned+=area_weight
    elif pa>=ca*0.9: earned+=area_weight*0.5; misses.append("متراژ کمی متفاوت است")
    else: misses.append("متراژ خارج از محدوده است")
    feature_weight=weights.get("features",0)
    if feature_weight:
        if not required: earned+=feature_weight
        else:
            available=sum(1 for k,v in required.items() if v and str(fields.get(k,"")).casefold()==str(v).casefold())
            needed=sum(1 for v in required.values() if v)
            earned+=feature_weight*(available/needed if needed else 1)
    for key,w in weights.items():
        if key in ("budget","location","area","features"): continue
        if key in fields and fields[key]:
            earned+=w
        else:
            earned+=w*0.5
            misses.append(f"اطلاعات «{key}» کامل نیست")
    score=max(0,min(100,round(earned/total*100)))
    return score,misses
